import { google } from 'googleapis';

import { env } from './env.js';

export function createOAuthClient() {
  return new google.auth.OAuth2(
    env('GOOGLE_CLIENT_ID'),
    env('GOOGLE_CLIENT_SECRET'),
    env('GOOGLE_REDIRECT_URI'),
  );
}

export function buildAuthUrl({ teacherId }) {
  const oauth2 = createOAuthClient();
  const scopes = [env('GOOGLE_DRIVE_SCOPE', 'https://www.googleapis.com/auth/drive.file')];

  return oauth2.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: scopes,
    state: teacherId,
  });
}

export async function exchangeCodeForTokens(code) {
  const oauth2 = createOAuthClient();
  const { tokens } = await oauth2.getToken(code);
  return tokens;
}

export async function driveClientFromRefreshToken(refreshToken) {
  const oauth2 = createOAuthClient();
  oauth2.setCredentials({ refresh_token: refreshToken });
  // Ensure we have an access token now (googleapis will refresh as needed too).
  await oauth2.getAccessToken();
  return google.drive({ version: 'v3', auth: oauth2 });
}

export async function accessTokenFromRefreshToken(refreshToken) {
  const oauth2 = createOAuthClient();
  oauth2.setCredentials({ refresh_token: refreshToken });
  const tokenRes = await oauth2.getAccessToken();
  const token = tokenRes?.token;
  if (!token) throw new Error('Could not mint access token.');
  return token;
}

